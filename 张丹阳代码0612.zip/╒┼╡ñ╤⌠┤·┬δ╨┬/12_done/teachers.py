import pandas as pd

teacher_info_pd = pd.read_csv('teacher_info.csv')
print(teacher_info_pd)
